$(document).ready(function () {
    $('#list-view-table').DataTable();
});