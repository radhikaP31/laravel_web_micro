<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Admin Dashboard | Microfluid Process Equipment')); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('metaname', null, []); ?> 
        <?php echo e(__('My Title')); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('metadesc', null, []); ?> 
        <?php echo e(__('My Description')); ?>

     <?php $__env->endSlot(); ?>
    <main style="margin-top: 58px">
        <div class="pt-4">

            <h2 class="col-md-12 header-font-size pb-5 primary-text"><?php echo e($title); ?>

                <?php if(array_key_exists('add',$action)): ?>
                <a href="<?php echo e(route($action['add'])); ?>" class="btn btn-primary col-md-2 col-md-offset-10 text-center">Add</a>
                <?php endif; ?>
            </h2>
            <table id="list-view-table" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <?php $__currentLoopData = $header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(ucfirst(str_replace('_',' ',$title))); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($value->$name); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <?php if(array_key_exists('edit', $action)): ?>
                            <a href="<?php echo e(route($action['edit'], ['id' => $value->id])); ?>" class="fa fa-edit pr-3" title="Edit" class=""></a>
                            <?php endif; ?>
                            <?php if(array_key_exists('delete', $action)): ?>
                            <a href="<?php echo e(route($action['delete'], ['id' => $value->id])); ?>" class="fa fa-trash pr-3" title="Delete" class=""></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/admin/listview.blade.php ENDPATH**/ ?>