<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Admin Dashboard | Microfluid Process Equipment')); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('metaname', null, []); ?> 
        <?php echo e(__('My Title')); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('metadesc', null, []); ?> 
        <?php echo e(__('My Description')); ?>

     <?php $__env->endSlot(); ?>
    <section class="contact container-fluid" id="contact">
            <div class="col-md-12 content">
                <div class="section-title text-center">
                    <h2 class="primary-text header-font-size">Login</strong></h2>
                </div>
                <div class=" col-lg-10">
                    <form method="post" action="<?php echo e(route('login.verify')); ?>" enctype="multipart/form-data" id="contactForm" class="contactForm mb-5">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12 form-group mb-3">
                                <label for="username" class="col-form-label">Username <span class="text-red">*</span></span></label>
                                <input type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>" placeholder="Your Username" />
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red text-10"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 form-group mb-3">
                                <label for="password" class="col-form-label">Password<span class="text-red">*</span></label>
                                <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" placeholder="Your Password" />
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red text-10"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="text-center"><button type="submit" class="btn btn-primary primary-text rounded-0 py-2 px-4 submit_inquiry">Login</button></div>
                    </form>
                </div>
            </div>
    </section><!-- End Contact Section -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>