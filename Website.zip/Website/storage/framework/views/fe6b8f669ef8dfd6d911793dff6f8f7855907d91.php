<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <?php $__env->startSection('title',"$metaDetails->meta_title"); ?>
  <?php $__env->startSection('metadesc',"$metaDetails->meta_description"); ?>
  <?php $__env->startSection('metakeyword',"$metaDetails->meta_keywords"); ?>

  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success alert-block container mb-3">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>

  <?php echo e(Breadcrumbs::render('industries')); ?>

  <main id="main">
    <!-- <hr style="margin: 2% 10%;background: #b5b5b5;" /> -->
    <!-- ======= Industries Section ======= -->
    <section id="industries" class="industries">
      <div class="container">
        <section id="field-appilication" class="field-appilication" style="background: #fff !important">
          <div class="container">
            <div class="row">
              <div class="col-lg-4 col-md-6 align-items-stretch min-height310 mt-4">
                <div class="icon-box white-bg">
                  <h4 class="primary-text header-font-size" style="text-align: left;padding-left: 7px;">Field of <br>Application</h4>
                  <hr style="width: 47%;margin-left: 6px;border-width: 4px;border-top: solid var(--secondary_color);">
                  <h4 class="primary-text body-font-size" style="text-align: left;padding-left: 7px;">Find a right solutions for your industry!!</h4>
                </div>
              </div>
              <?php if($fieldApplication->count() > 0): ?>
              <?php $__currentLoopData = $fieldApplication; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-6 align-items-stretch mt-4">
                <div class="section-field">
                  <div class="field-header">
                    <a target="_self" href="<?php echo config('app.base_url') . '/industry/' . $field->slug; ?>">
                      <div class="section-background"></div>
                      <img alt="<?php echo e($field->mstr_nm); ?>" src="<?php echo e(url($field->mstr_img)); ?>">
                      <div class="section-text">
                        <h3 class="industry-title-text font-size-20 font-family-sans-serif text-white"><?php echo e($field->mstr_nm); ?></h3>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
            <br>
          </div>
        </section>
      </div>
    </section><!-- End Industries Section -->
  </main><!-- End #main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/industry/allIndustries.blade.php ENDPATH**/ ?>