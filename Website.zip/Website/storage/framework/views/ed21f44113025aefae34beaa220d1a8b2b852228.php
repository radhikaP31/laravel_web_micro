<?php if (! ($breadcrumbs->isEmpty())): ?>

<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs" style="padding: 0px;height: 100%;background-image: url(<?php echo e(url('images/breadcrumb/breadcrumb_img.png')); ?>);background-size: cover;">
  <div class="opacity-breadcrumbs" style="position: absolute;z-index: 0;opacity: 0.8;width: 100%;height: 100%;background: white;"></div>
  <div class="col-md-12 d-flex justify-content-between align-items-center" style="bottom: -4%;height: auto; min-height: 8em;">
    <h3 class="text-left primary-text breadcrumb-text"><?php echo e(__('Microfluid is one of the leading manufacturer of process equipment ')); ?></h3>
  </div>
  <div class="col-md-12 d-flex justify-content-between align-items-center" style="bottom: -9%;background: rgb(0 0 0 / 48%);letter-spacing: 1.3px;">
    <h2 class="primary-text breadcrumb-link" style="margin: 9px 4rem;">
      <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(!is_null($breadcrumb->url) && !$loop->last): ?>
      <a href="<?php echo e($breadcrumb->url); ?>"><?php echo e($breadcrumb->title); ?></a>
      <?php else: ?>
      <a class="breadcrumb-item active text-white"><?php echo e(ucfirst($breadcrumb->title)); ?></a>
      <?php endif; ?>
      <?php if(!$loop->last): ?>
      |
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h2>
  </div>
  </div>
</section>
<!-- End Breadcrumbs -->
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/components/breadcrumb.blade.php ENDPATH**/ ?>