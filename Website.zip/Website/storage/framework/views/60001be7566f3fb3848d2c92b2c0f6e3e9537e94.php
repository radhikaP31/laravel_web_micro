<?php $__env->startComponent('mail::message'); ?>
<h2>Hello <?php echo e($body['name']); ?>,</h2>
<p>Greetings of the day.</p>
<p>Thank you for connecting us!!</p>
<p>Your inquiry received successfully.. We'll get back to you soon..</p>
Thanks & Regards,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/emails/InquiryMail.blade.php ENDPATH**/ ?>