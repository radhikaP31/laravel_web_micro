<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
    <?php echo e(__('Industry | Microfluid Process Equipment')); ?>

   <?php $__env->endSlot(); ?>
   <?php $__env->slot('metaname', null, []); ?> 
    <?php echo e(__('Industry')); ?>

   <?php $__env->endSlot(); ?>
   <?php $__env->slot('metadesc', null, []); ?> 
    <?php echo e(__('Microfluid process equipment was founded in 2019 by highly qualified engineers, who have more than 25 years experience in manufacturing and process industries and high pressure reciprocating pumps.')); ?>

   <?php $__env->endSlot(); ?>

  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success alert-block container mb-3">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>

  <?php echo e(Breadcrumbs::render('industry')); ?>

  <main id="main" class="industry-page">
    <!-- ======= Industry Section ======= -->
    <section id="industry" class="industry-section row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 3%;">
        <h2 class="primary-text header-font-size font-30" style="font-weight:bolder;"><?php echo e($fieldApplication->mstr_nm); ?></h2>
      </div>
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="col-md-7">
          <p class="text-gray letter-spacing text-justify font-family-sans-serif"><?php echo e($fieldApplication->mstr_desc); ?></p>
          <?php echo $fieldApplication->section_desc ?>
        </div>
        <div class="col-md-5">
          <img alt="<?php echo e($fieldApplication->mstr_nm); ?>" src="<?php echo e(url($fieldApplication->mstr_img)); ?>" class="field-image" />
        </div>
      </div>
    </section><!-- End Industry Section -->
  </main><!-- End #main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/industry/singleIndustry.blade.php ENDPATH**/ ?>