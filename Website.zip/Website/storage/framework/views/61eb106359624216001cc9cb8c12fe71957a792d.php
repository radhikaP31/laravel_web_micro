<footer class="col-md-12 footer padding0">
    <div class="d-md-flex primary-bg" style="padding: 10px 35px 10px 35px;">
        <div class="mr-md-auto text-center text-md-left container">
            <p class="text-white" style="letter-spacing: 1.2px;">Download | Career | HR Policy | Terms & Conditions | Contact Us | Microfluid</p>
            <div class="copyright text-white">
                <p style="letter-spacing: 0.9px;">&copy; Copyright 2022 - All rights reserved by <strong><span>Microfluid Process Equipment</span></strong></p>
            </div>
        </div>
    </div>
</footer>
<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<!-- <script src="assets/vendor/jquery/jquery.min.js"></script> -->
<script src="<?php echo e(asset('files/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/jquery.easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/jquery-sticky/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('files/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/venobox/venobox.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/waypoints/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/owl.carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('files/aos/aos.js')); ?>"></script><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/layouts/admin/adminfooter.blade.php ENDPATH**/ ?>