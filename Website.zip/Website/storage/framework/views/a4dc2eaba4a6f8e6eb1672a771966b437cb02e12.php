<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/microfluid_9/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>