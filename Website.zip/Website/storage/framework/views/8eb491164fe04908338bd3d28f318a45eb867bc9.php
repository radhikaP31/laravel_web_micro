<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title', null, ['metaname' => ''.e(__('tagstitle')).'','meta-content' => ''.e(__('content')).'']); ?> 
            <?php echo e(__('Home | Microfluid Process Equipment')); ?>

     <?php $__env->endSlot(); ?>

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block container mb-3">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>


<?php echo e(Breadcrumbs::render('about')); ?>

  <main id="main">
    <!-- <hr style="margin: 2% 10%;background: #b5b5b5;" /> -->
    <!-- ======= About Us Section ======= -->
    <section class="about-us container-fluid" id="about-us">
      <div class="row col-md-12 col-lg-12 col-sm-12 col-xs-12 m-0">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="border-right: 1px solid var(--primary_color);">
          <div class="about-list-group">
                  <?php if($aboutUsInformation->count() > 0): ?>
                    <?php $__currentLoopData = $aboutUsInformation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a href="javascript:void(0)" class="list-group-item text-black block-filter" data-block_type="<?php echo e($about->tab_name); ?>"><?php echo e($about->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
          </div> 
          <!-- <nav class="navbar navbar-default block-filter-section" style="display: block;">
            <ul class="about-us-nav nav navbar-nav">
              <?php if($aboutUsInformation->count() > 0): ?>
                <?php $__currentLoopData = $aboutUsInformation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="block-filter" data-block_type="<?php echo e($about->tab_name); ?>">
                        <a href="javascript:void(0)" class="text-black"><?php echo e($about->name); ?></a>
                      </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>         
            </ul>  
          </nav> -->
        </div>
        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 container about-us-blocks " style="margin: unset;">
          <?php if($aboutUsInformation->count() > 0): ?>
            <?php $__currentLoopData = $aboutUsInformation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $about_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="block-type <?php echo e('block-type-'.$about_details->tab_name); ?>" data-block_type="<?php echo e($about_details->tab_name); ?>" style="display: none;">
                  <div class="section-title ">
                      <h2 class="primary-text header-font-size text-center mb-4 "><?php echo e($about_details->name); ?>

                      </h2>
                  </div>
                  <?php echo $about_details->description //don't change it ?>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        
      </div>
    </section><!-- End About Us Section -->
  </main><!-- End #main -->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/about.blade.php ENDPATH**/ ?>