<?php foreach($attributes->onlyProps([
'metaname' => 'Microfluid',
'meta-content' => 'Microfluid Process Equipment',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'metaname' => 'Microfluid',
'meta-content' => 'Microfluid Process Equipment',
]); ?>
<?php foreach (array_filter(([
'metaname' => 'Microfluid',
'meta-content' => 'Microfluid Process Equipment',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta content="<?php echo $__env->yieldContent('metadesc'); ?>" name="description">
    <meta content="<?php echo $__env->yieldContent('metakeyword'); ?>" name="keywords">
    <meta content="Microfluid Process Equipment" name="author">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="canonical" href="https://microfluidprocess.com/">
    <link rel="shortlink" href="https://microfluidprocess.com/">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('images/favicon/ms-icon-144x144.png')); ?>">
    <meta name="theme-color" content="#ffffff">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-100">
        <?php echo $__env->make('layouts.headerscroll', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Page Content -->
        <?php echo e($slot); ?>

    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/layouts/app.blade.php ENDPATH**/ ?>