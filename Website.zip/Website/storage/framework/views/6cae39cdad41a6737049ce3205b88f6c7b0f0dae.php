<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <?php $__env->startSection('title',"$productData->meta_title"); ?>
  <?php $__env->startSection('metadesc',"$productData->meta_description"); ?>
  <?php $__env->startSection('metakeyword',"$productData->meta_keywords"); ?>

  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success alert-block container mb-3">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>

  <?php echo e(Breadcrumbs::render('product',$productData->p_name)); ?>

  <main id="main" class="all-product-main">
    <!-- ======= Product Section ======= -->
    <section class="product row white-bg" id="product">
      <?php if($productData->count() > 0): ?>
      <!-- main if 1 -->
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 3%;">
        <h2 class="primary-text header-font-size font-30" style="font-weight:bolder;"><?php echo e($productData->p_name); ?></h2>
      </div>
      <div class="col-md-5 product-img">
        <?php if($productData->image->count() > 0): ?>
        <!-- product image start 1 -->
        <?php $__currentLoopData = $productData->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- product image start 2 -->
        <div class="my-product-slides">
          <img src="<?php echo e(url($image['img_path'])); ?>" class="product_active_img">
        </div>
        <!-- product image end 2 -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- product image end 1 -->
        <?php endif; ?>

        <a class="prev_arrow prev-product-img" data-slide_count="-1">
          <span class="iconify secondary-text" data-icon="ic:round-keyboard-double-arrow-left" data-width="32" data-height="32"></span>
        </a>
        <a class="next_arrow next-product-img" data-slide_count="1">
          <span class="iconify secondary-text" data-icon="ic:round-keyboard-double-arrow-right" data-width="32" data-height="32"></span>
        </a>

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top:10px;">
          <?php if($productData->image->count() > 0): ?>
          <!-- product image start 1 -->
          <?php $count = 1; ?>
          <?php $__currentLoopData = $productData->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- product image start 2 -->
          <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="width:auto;">
            <img class="product-image product-cursor " src="<?php echo e(url($image['img_path'])); ?>" style="width: auto; height: 70px;
    padding-bottom: 6px" data-slide="<?= $count; ?>">
          </div>
          <?php $count++; ?>
          <!-- product image end 2 -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- product image end 1 -->
          <?php endif; ?>
        </div>
      </div>

      <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 2%;">
          <p class="letter-spacing text-justify font-family-sans-serif font-16 text-gray"><?php echo $productData->p_description ?></p>
        </div>
        <!-- <div class="row col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 2%;">
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <a href="#" class="btn prod_desc_btn" data-toggle="modal" data-target="#req_quote">
              <img src="<?php echo e(url('images/icons/quote.png')); ?>" style="height: 96px; width: auto;" /><span class="header-font-size">Request Quote</span></a>
          </div>
        </div> -->
      </div>

      <!-- product keys nav section start -->
      <!-- <hr style="width: 100%;border-top: 1px solid var(--secondary_color);margin-bottom: 0px;"> -->
      <nav class="navbar navbar-expand-lg navbar-light bg-light secondary-page-menu col-md-12">
        <ul class="navbar-nav">
          <?php if($productData->key->count() > 0): ?>
          <!-- product key start 1 -->
          <?php $__currentLoopData = $productData->key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- product key start 2 -->
          <?php $__currentLoopData = $navDetails[$product_key->tab_name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navKey => $navValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="nav-item active">
            <a class="nav-link font-17" href="#<?php echo e($navValue->key_name); ?>"><?= $navValue->name; ?></a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- product key end 2 -->
          <?php endif; ?>
          <!-- product key end 1 -->
        </ul>
      </nav>

      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 2%;">
        <?php if($productData->key->count() > 0): ?>
        <!-- product feature start 1 -->
        <?php $__currentLoopData = $productData->key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- product feature start 2 -->
        <?php $__currentLoopData = $navDetails[$product_key->tab_name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navKey => $navValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="<?php echo e($navValue->key_name); ?>" style="padding-top: 4%;">
          <h4 class="primary-text product-header-font-size text-left mb-3"><?php echo e($navValue->name); ?></h4>
          <?php echo $navValue->description ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- product key end 1 -->
        <?php endif; ?>
        <!-- product key end 2 -->
      </div>
      <!-- product keys nav section end -->
      <?php endif; ?>
      <!-- end main if 1 -->
    </section><!-- End Product Section -->
  </main><!-- End #main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<script type=" text/javascript">
  //product page js start
  let slideIndex = 1;
  showSlides(slideIndex);

  $('.prev-product-img,.next-product-img').click(function() {
    showSlides(slideIndex += jQuery(this).data('slide_count'));
  });

  $('.product-cursor').click(function() {
    showSlides(slideIndex = jQuery(this).data('slide'));
  });

  function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("my-product-slides");
    let dots = document.getElementsByClassName("product-image");
    if (n > slides.length) {
      slideIndex = 1
    }
    if (n < 1) {
      slideIndex = slides.length
    }
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active_product", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active_product";
  } //product page js end
</script><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/product/singleProduct.blade.php ENDPATH**/ ?>