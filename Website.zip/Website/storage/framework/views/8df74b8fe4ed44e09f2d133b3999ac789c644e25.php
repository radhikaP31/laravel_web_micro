<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title',"$metaDetails->meta_title"); ?>
    <?php $__env->startSection('metadesc',"$metaDetails->meta_description"); ?>
    <?php $__env->startSection('metakeyword',"$metaDetails->meta_keywords"); ?>

    <?php echo e(Breadcrumbs::render('contact')); ?>

    <main id="main" class="contact-us-page">
        <!-- ======= Contact Section ======= -->
        <section class="contact row white-bg" id="contact">
            <div class="col-md-12">
                <div class="col-md-6">
                    <div class="info-wrap">
                        <div class="row contact-details">
                            <div class="col-md-12">
                                <div class="info-box">
                                    <i class="icofont-google-map"></i>
                                    <h4 class="primary-text product-header-font-size text-left mb-2">Location:</h4>
                                    <p class="letter-spacing text-justify font-family-sans-serif pb-2 text-gray">30, Darshan Industrial Park, Singarva Road,<br> Kathwada GIDC, Ahmedabad - 382430,<br> Gujarat, India</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <i class="icofont-envelope"></i>
                                    <h4 class="primary-text product-header-font-size text-left mb-2">Email:</h4>
                                    <p class="letter-spacing text-justify font-family-sans-serif pb-2 text-gray"><a class="letter-spacing text-justify font-family-sans-serif pb-2 text-gray hover-mail" href="mailto:sales@microfluidprocess.com">sales@microfluidprocess.com</a></p>
                                </div>
                            </div>
                            <div class=" col-md-6">
                                <div class="info-box">
                                    <i class="icofont-phone"></i>
                                    <h4 class="primary-text product-header-font-size text-left mb-2">Call:</h4>
                                    <p class="letter-spacing text-justify font-family-sans-serif pb-2 text-gray">+91 70168 65019<br>Parth Patel</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 map-section">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d918.0252235723684!2d72.68446002916806!3d23.02006739905966!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7c18885d95e2866!2zMjPCsDAxJzEyLjIiTiA3MsKwNDEnMDYuMCJF!5e0!3m2!1sen!2sin!4v1668525859982!5m2!1sen!2sin" style="border:0; width: 100%; height: 300px;" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
            <div class="container">
                <div class="row mt-5 justify-content-center contact-form">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="primary-text header-font-size">Contact Us</h2>
                        </div>
                        <form method="POST" action="<?php echo e(route('contact_add')); ?>" enctype="multipart/form-data" id="contactForm" class="contactForm mb-5">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 form-group mb-4">
                                    <input type="text" name="contact[name]" class="form-control" value="<?php echo e(old('contact.name')); ?>" placeholder="Your Name*" />
                                    <?php $__errorArgs = ['contact.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10 is-invalid"><?php echo e($errors->first('contact.name')); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group mb-4">
                                    <input type="text" name="contact[email]" value="<?php echo e(old('contact.email')); ?>" class="form-control" placeholder="Your Email*" />
                                    <?php $__errorArgs = ['contact.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10 is-invalid"><?php echo e($errors->first('contact.email')); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2 form-group mb-4">
                                    <select class="custom-select country_code" name="contact[country_code]">
                                        <option value="">ISD Code</option>
                                        <?php $__currentLoopData = $country_code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->isd_code); ?>" <?php echo e((old("contact.country_code") == $value->isd_code ? "selected":"")); ?>><?php echo e($value->isd_code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['contact.country_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10 is-invalid"><?php echo e($errors->first('contact.country_code')); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 form-group mb-4">
                                    <input type="text" name="contact[contact_no]" class="form-control" value="<?php echo e(old('contact.contact_no')); ?>" placeholder="Your Contact Number*" />
                                    <?php $__errorArgs = ['contact.contact_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10 is-invalid"><?php echo e($errors->first('contact.contact_no')); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group mb-4">
                                    <input type="text" name="contact[company_name]" value="<?php echo e(old('contact.company_name')); ?>" class="form-control" placeholder="Your Company Name*" />
                                    <?php $__errorArgs = ['contact.company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10 is-invalid"><?php echo e($errors->first('contact.company_name')); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 form-group mb-4">
                                    <input class="form-control" type="file" id="attachment" name="contact[attachment]">
                                    <?php $__errorArgs = ['contact.attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class=" text-red text-10 is-invalid"><?php echo e($errors->first('contact.attachment')); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 form-group mb-4">
                                    <textarea class="form-control" name="contact[message]" id="message" cols="30" rows="4" placeholder="Write your Message Here*"><?php echo e(old('contact.message')); ?></textarea>
                                    <?php $__errorArgs = ['contact.message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10 is-invalid"><?php echo e($errors->first('contact.message')); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="text-center mt-4"><button type="submit" class="btn btn-primary primary-text rounded-0 py-2 px-4 submit_inquiry font-16"><b>Send Message</b></button></div>
                        </form>
                    </div>
                </div>
            </div>
        </section><!-- End Contact Section -->
        <?php if($errors->any()): ?>
        <script>
            document.querySelector('.is-invalid').scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        </script>
        <?php endif; ?>
    </main><!-- End #main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/contact/contact.blade.php ENDPATH**/ ?>