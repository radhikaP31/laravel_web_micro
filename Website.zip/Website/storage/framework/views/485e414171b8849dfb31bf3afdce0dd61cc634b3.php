<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, ['metaname' => ''.e(__('tagstitle')).'','meta-content' => ''.e(__('content')).'']); ?> 
        <?php echo e(__('Inquiry | Microfluid Process Equipment')); ?>

     <?php $__env->endSlot(); ?>

    <!--     <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block container mb-3">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?> -->

    <?php echo e(Breadcrumbs::render('inquiry')); ?>

    <main id="main">
        <!-- ======= Inquiry Section ======= -->
        <section class="container inquiry_form container-fluid" id="inquiry_form">
            <div class="row align-items-stretch contact-wrap">
                <div class="col-md-12">
                    <div class="form h-100">
                        <h2 class="primary-text header-font-size mb-3">Please describe your requirements. <br> Our Team will connect you shortly!!<br></h2>
                        <form method="post" action="/inquiry/add" enctype="multipart/form-data" id="contactForm" class="contactForm mb-5">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 form-group mb-3">
                                    <label for="name" class="col-form-label">Name <span class="text-red">*</span></span></label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Your Name" />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group mb-3">
                                    <label for="email" class="col-form-label">Email <span class="text-red">*</span></label>
                                    <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Your Email" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group mb-3">
                                    <label for="phone" class="col-form-label">Mobile No <span class="text-red">*</span></label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>" placeholder="Your Mobile Number" />
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="checkbox" name="is_whatsapp_no" value="yes" />
                                    <label for="" class="col-form-label">Is Whatsapp Number?</label>
                                </div>
                                <div class="col-md-6 form-group mb-3">
                                    <label for="company_name" class="col-form-label">Company Name <span class="text-red">*</span></label>
                                    <input type="text" name="company_name" value="<?php echo e(old('company_name')); ?>" class="form-control" placeholder="Your Company Name" />
                                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group mb-3">
                                    <label for="company_address" class="col-form-label">Company Address </label>
                                    <input class="form-control" name="company_address" id="company_address" value="<?php echo e(old('company_address')); ?>" placeholder="Your Company Address" />
                                </div>
                                <div class="col-md-6 form-group mb-3">
                                    <label for="" class="col-form-label">Website </label>
                                    <input type="text" name="website" value="<?php echo e(old('website')); ?>" class="form-control" placeholder="Your Website Link" />
                                    <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group mb-3">
                                    <label for="country_id" class="col-form-label">Country <span class="text-red">*</span></label>
                                    <select class="custom-select country_id" name="country_id" id="country_id" onchange="selectState(this.value)">
                                        <option value="">Select a Country</option>
                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>" <?php echo e((old("country_id") == $value->id ? "selected":"")); ?>><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group mb-3">
                                    <label for="state_id" class="col-form-label">State <span class="text-red">*</span></label>
                                    <select class="custom-select state_id" name="state_id" id="state_id">
                                        <option value="">Select a State</option>
                                        <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>" <?php echo e((old("state_id") == $value->id ? "selected":"")); ?>><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group mb-3">
                                    <label for="city" class="col-form-label">City <span class="text-red">*</span></label>
                                    <input type="text" name="city" class="form-control" value="<?php echo e(old('city')); ?>" placeholder="Your City Name" />
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 form-group mb-3">
                                    <label for="post_code" class="col-form-label">Post Code <span class="text-red">*</span></label>
                                    <input type="text" name="post_code" class="form-control" value="<?php echo e(old('post_code')); ?>" placeholder="Your Post Code" />
                                    <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 form-group mb-3">
                                    <label for="attachment" class="col-form-label">Attachment </label>
                                    <input class="form-control" type="file" id="attachment" name="attachment">
                                    <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class=" text-red text-10"><?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 form-group mb-3">
                                    <label for="message" class="col-form-label">Message <span class="text-red">*</span></label>
                                    <textarea class="form-control" name="message" id="message" cols="30" rows="4" placeholder="Write your message"><?php echo e(old('message')); ?></textarea>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red text-10"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12 form-group">
                                    <button type="submit" class="btn btn-primary font-16 primary-text submit_inquiry">Send Inquiry</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section><!-- End Inquiry Section -->
    </main><!-- End #main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script>
    function selectState(countryId) {
        $.ajax({
            type: "POST",
            url: "/inquiry/selectState/" + countryId,
            data: {
                countryId: countryId,
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            beforeSend: function() {
                $(".state_id").html("<option>Please Wait...</option>")
                $(".state_id").prop("disabled", true)
            },
            success: function(response) {
                $(".state_id").html(response)
                $(".state_id").prop("disabled", false)
            }
        });
    }
</script><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/inquiry/inquiry.blade.php ENDPATH**/ ?>