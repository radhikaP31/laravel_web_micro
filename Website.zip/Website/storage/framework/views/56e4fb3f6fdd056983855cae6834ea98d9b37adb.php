<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title',"$metaDetails->meta_title"); ?>
    <?php $__env->startSection('metadesc',"$metaDetails->meta_description"); ?>
    <?php $__env->startSection('metakeyword',"$metaDetails->meta_keywords"); ?>

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block container mb-3">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>

    <?php echo e(Breadcrumbs::render('download')); ?>

    <main id="main">
        <!-- <hr style="margin: 2% 10%;background: #b5b5b5;" /> -->
        <!-- ======= Download Section ======= -->
        <section id="download" class="download">
            <div class="container">
                <div class="row col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h2 class=" primary-text header-font-size">Download Our product Catalogue</h2>
                </div>
                <div class="row col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php if($downloadData->count() > 0): ?>
                    <?php $__currentLoopData = $downloadData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $field->description ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </section><!-- End Download Section -->
    </main><!-- End #main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/download/download.blade.php ENDPATH**/ ?>