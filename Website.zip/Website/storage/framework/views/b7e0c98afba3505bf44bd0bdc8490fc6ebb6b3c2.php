<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <?php $__env->startSection('title',"$metaDetails->meta_title"); ?>
  <?php $__env->startSection('metadesc',"$metaDetails->meta_description"); ?>
  <?php $__env->startSection('metakeyword',"$metaDetails->meta_keywords"); ?>

  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success alert-block container mb-3">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <strong><?php echo e($message); ?></strong>
  </div>
  <?php endif; ?>

  <?php echo e(Breadcrumbs::render('products')); ?>

  <main id="main">
    <!-- ======= Product Section ======= -->
    <section class="all-product container-fluid" id="product">
      <div class="row col-md-12 col-lg-12 col-sm-12 col-xs-12 m-0">
        <!-- Product category and sub category sidebar section end-->
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="border-right: 1px solid #e7e7e7;">
          <div class="list-group product-list-group">
            <?php if($allCategory->count() > 0): ?>
            <?php $__currentLoopData = $allCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group-wrapper">
              <a href="<?php echo config('app.base_url') . '/product/' . $category->id; ?>" class="product-list-group-item list-group-item font-20 product-cat letter-spacing <?php if (request()->id == $category->id) {echo "active";} ?>" data-sc_cat="<?php echo e($category->c_code); ?>"><?php echo e($category->c_name); ?></a>
              <!-- Product sub category sidebar section start-->
              <div class="list-group product-cat-filter product-cat-filter-<?php echo e($category->c_code); ?>" data-sc_cat="<?php echo e($category->c_code); ?> <?php echo e(request()->id); ?>" style="<?php if (request()->id != $category->id) {"display: none;";} ?>">
                <?php if($category->subCategory->count() > 0): ?>
                <?php $__currentLoopData = $category->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($subcategory->is_deleted == 0): ?>
                <a href="<?php echo config('app.base_url') . '/product/' . $category->id . '/' . $subcategory->id; ?>" class="product-item list-group-item body-font-size"><?php echo e($subcategory->sc_name); ?></a>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            </div>
            <!-- Product sub category sidebar section end-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
        </div>
        <!-- Product category and sub category sidebar section end-->
        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 container" style="margin: unset;">
          <!-- Display Product Sub Category title, description start-->
          <?php if($productData->count() > 0): ?>
          <?php $__currentLoopData = $productData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $title_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($sub_cat_id): ?>
          <h2 class="primary-text header-font-size"><?php echo e($title_product->sc_name); ?></h2>
          <!-- <p class="font-18"><?php echo e($title_product->sc_description); ?></p> -->
          <?php else: ?>
          <h2 class=" primary-text header-font-size"><?php echo e($title_product->c_name); ?></h2>
          <!-- <p class="font-18"><?php echo e($title_product->c_description); ?></p> -->
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          <!-- Display Product Sub Category title, description end-->

          <!-- Display Category wise Products start-->
          <div class="row services" style="padding: 3%;">
            <?php if($product_data && $product_data->count() > 0): ?>
            <?php $__currentLoopData = $product_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 align-items-stretch">
              <div class="product-icon-box font-18 rounded mb-5 product-box">
                <a href="<?php echo config('app.base_url') . '/products/' . $product->slug; ?>" class="service_name primary-text">
                  <div class="icon">
                    <img alt="<?php echo e($product->p_name); ?>" src="<?php echo e(url($product->p_image)); ?>">
                  </div>
                  <div>
                    <div style="height:47px;">
                      <h4 class="text-black" style=" padding-top: 8px;"><?php echo e($product->p_name); ?></h4>
                    </div>
                  </div>
                </a>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="m-auto primary-text row"> Sorry, There is no product available in this category. We'll update it soon. </div>
            <?php endif; ?>
            <br>
          </div>
          <!-- Display Category wise Products end-->
        </div>
      </div>
    </section><!-- End Product Section -->
  </main><!-- End #main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/product/allProducts.blade.php ENDPATH**/ ?>