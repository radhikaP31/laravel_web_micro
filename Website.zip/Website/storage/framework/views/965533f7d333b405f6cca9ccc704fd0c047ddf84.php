<header id="header" class="header">
    <!-- email, contact info -->
    <div class="container d-flex align-items-center top-container" style="height:68px;padding-left: 0%;padding-right: 0%;margin-bottom: 0%;">
        <a href="<?php echo config('app.base_url'); ?>" class="logo mr-auto"><img src="<?php echo e(asset('images/Logo.png')); ?>" alt="" class="img-fluid"></a>
        <span class="primary-text" style="margin-right: 4%;"><i class="fa fa-phone fa-rotate-90"></i> +91 70168 65019 </span>
        <span class="primary-text" style="margin-right: 4%;width: 25%;letter-spacing: 1px;"><i class="fa fa-envelope"></i>&nbsp;<a class="primary-text hover-mail" href="mailto:sales@microfluidprocess.com">sales@microfluidprocess.com</a> </span>
    </div>
</header><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/layouts/admin/adminheaderscroll.blade.php ENDPATH**/ ?>