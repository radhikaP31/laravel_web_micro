<div>
    <?php if($type === 'text' || $type === 'email'): ?>
        <label for="<?php echo e($name); ?>" class="col-form-label"><?php echo e($label); ?><span class="text-red">*</span></span></label>
        <input type="text" name="<?php echo e($name); ?>" class="form-control" value="<?php echo e(old($name)); ?>" placeholder="<?php echo e($placeholder); ?>" />
        <?php $__errorArgs = ['<?php echo e($name); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-red text-10"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php elseif($type === 'email'): ?>
    <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <input type="email" name="<?php echo e($name); ?>" value="<?php echo e($value ?? ''); ?>">
    <?php endif; ?>
</div><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/components/dynamic-form-field.blade.php ENDPATH**/ ?>