<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, ['metaname' => ''.e(__('tagstitle')).'','meta-content' => ''.e(__('content')).'']); ?> 
            <?php echo e(__('Home | Microfluid Process Equipment')); ?>

     <?php $__env->endSlot(); ?>

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block container mb-3">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>


<?php echo e(Breadcrumbs::render('product')); ?>

<main id="main">
   <!-- ======= Product Section ======= -->
  <section class="row col-md-12 product container-fluid" id="product" style="padding-right: 0%;margin: 0px;padding-left: 0px;">

      <?php if($productData->count() > 0): ?> <!-- main if 1 -->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 2%;">
          <h2 class="primary-text header-font-size"><?php echo e($productData->p_name); ?></h2>
        </div>
        <div class="col-md-4" style="border-right: 1px solid black;">
          <?php if($productData->image->count() > 0): ?> <!-- product image start 1 -->
            <?php $__currentLoopData = $productData->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- product image start 2 -->
          
            <div class="my-product-slides">
              <div class="image-number-text">1 / 2</div>
              <img src="<?php echo e(url($image['img_path'])); ?>" class="product_active_img">
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- product image end 1 -->
          <?php endif; ?> <!-- product image end 2 -->

          <a class="prev_arrow prev-product-img" data-slide_count="-1">
            <span class="iconify secondary-text" data-icon="ic:round-keyboard-double-arrow-left" data-width="32" data-height="32"></span>
          </a>
          <a class="next_arrow next-product-img" data-slide_count="1">
            <span class="iconify secondary-text" data-icon="ic:round-keyboard-double-arrow-right" data-width="32" data-height="32"></span>
          </a>

          <div class="row col-md-12">
            <?php if($productData->image->count() > 0): ?> <!-- product image start 1 -->
            <?php $__currentLoopData = $productData->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- product image start 2 -->
              <?php $count = 1; ?>
                <div class="col-md-4">
                  <img class="product-image product-cursor " src="<?php echo e(url($image['img_path'])); ?>" style="width: auto; height: 70px;" data-slide="<?= $count; ?>">
                </div>

              <?php $count++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- product image end 1 -->
          <?php endif; ?> <!-- product image end 2 -->
          </div>
        </div>

        <div class="col-md-8">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="    padding-bottom: 2%;">
            <p><?php echo e($productData->p_description); ?></p>
          </div>
          <div class="row col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 2%;">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <a href="#" class="btn prod_desc_btn" data-toggle="modal" data-target="#req_quote">
                <img src="<?php echo e(url('images/icons/quote.png')); ?>" style="height: 96px; width: auto;" /><span class="header-font-size">Request Quote</span></a>
            </div>
          </div>
        </div>

        <!-- product keys nav section start -->
        <hr style="width: 100%;border-top: 1px solid var(--secondary_color);margin-bottom: 0px;">
          <nav class="navbar navbar-expand-lg navbar-light bg-light secondary-page-menu col-md-12">
            <div class="" id="navbarNav">
              <ul class="navbar-nav">

                  <?php if($productData->key->count() > 0): ?><!-- product key start 1 -->
                    <?php $count = 1; ?>
                    <?php $__currentLoopData = $productData->key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><!-- product key start 2 -->
                      <li class="nav-item active">
                        <a class="nav-link product-feature" href="#<?php echo e($product_key->tab_name); ?>" ><?= $product_key->key_name; ?></a>
                      </li>
                      <?php $count++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- product key end 1 -->
                  <?php endif; ?> <!-- product key end 2 -->

              </ul>
            </div>
          </nav>

          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 container" style="padding-bottom: 2%;">
            <?php if($productData->key->count() > 0): ?><!-- product feature start 1 -->
              <?php $__currentLoopData = $productData->key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><!-- product feature start 2 -->
                <div id="<?php echo e($product_key->tab_name); ?>" style=" padding-top: 2%;">
                  <h4 class="primary-text header-font-size" style="text-align: left;padding-left: 7px;"><?php echo e($product_key->key_name); ?></h4>
                  
                  <?php $__currentLoopData = $navDetails[$product_key->tab_name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navKey => $navValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <!-- <h2> <?php echo e($navValue->name); ?> </h2> -->
                      <div> <?php echo $navValue->description ?> </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- product key end 1 -->
            <?php endif; ?> <!-- product key end 2 -->

          </div>

          <!-- product keys nav section end -->

      <?php endif; ?> <!-- end main if 1 -->
  </section><!-- End Product Section -->
</main><!-- End #main -->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<script type="text/javascript">
  //product page js start
let slideIndex = 1;
showSlides(slideIndex);

$('.prev-product-img,.next-product-img').click(function() {
  showSlides(slideIndex += jQuery(this).data('slide_count'));
});

$('.product-cursor').click(function() {
  showSlides(slideIndex = jQuery(this).data('slide'));
});

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("my-product-slides");
  let dots = document.getElementsByClassName("product-image");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active_product", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active_product";
}
//product page js end
</script><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/product/product.blade.php ENDPATH**/ ?>