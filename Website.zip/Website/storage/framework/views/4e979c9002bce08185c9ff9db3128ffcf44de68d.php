<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Admin Dashboard | Microfluid Process Equipment')); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('metaname', null, []); ?> 
        <?php echo e(__('My Title')); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('metadesc', null, []); ?> 
        <?php echo e(__('My Description')); ?>

     <?php $__env->endSlot(); ?>
    <main style="margin-top: 58px">
        <div class="container pt-4">
            <form method="post" action="<?php echo e(route('common_type_add')); ?>" enctype="multipart/form-data" class="mb-5">
                <?php if (isset($component)) { $__componentOriginal450207fb094843fdad482226a852c77d556dc592 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DynamicFormField::class, ['type' => 'text','name' => 'username','label' => 'Username','value' => ''.e(old('username')).'','placeholder' => 'Your Name'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-form-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\DynamicFormField::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal450207fb094843fdad482226a852c77d556dc592)): ?>
<?php $component = $__componentOriginal450207fb094843fdad482226a852c77d556dc592; ?>
<?php unset($__componentOriginal450207fb094843fdad482226a852c77d556dc592); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal450207fb094843fdad482226a852c77d556dc592 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DynamicFormField::class, ['type' => 'email','name' => 'email','label' => 'Email Address','value' => ''.e(old('email')).'','placeholder' => 'Your Email'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-form-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\DynamicFormField::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal450207fb094843fdad482226a852c77d556dc592)): ?>
<?php $component = $__componentOriginal450207fb094843fdad482226a852c77d556dc592; ?>
<?php unset($__componentOriginal450207fb094843fdad482226a852c77d556dc592); ?>
<?php endif; ?>
            </form>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<style>

</style><?php /**PATH /opt/lampp/htdocs/microfluid_9/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>